# ColorFit — version finale de base

ColorFit est un site web full-stack conçu autour de la colorimétrie, des outfits et d'un abonnement Premium.

## Lancer en local

Prérequis : Node.js 20+.

```bash
cp .env.example .env
npm install
npm start
```

Puis ouvrir http://localhost:3000.

## Sécurité intégrée

- mots de passe hachés avec bcrypt (12 rounds)
- cookies de session HttpOnly + SameSite=Lax (+ Secure en production)
- sessions signées HMAC, durée limitée
- validation stricte des entrées avec Zod
- requêtes SQL exclusivement paramétrées (protection injection SQL)
- contraintes et clés étrangères SQLite
- rate limiting sur l'API et particulièrement l'authentification
- Helmet + CSP + Referrer-Policy + protections clickjacking
- limitation de taille des requêtes JSON
- validation type/taille des photos côté navigateur ; les photos ne sont pas envoyées au serveur par l'analyse V1
- contrôle d'origine pour les requêtes mutatives
- secrets Stripe uniquement côté serveur
- aucun numéro de carte bancaire stocké par ColorFit : Stripe Checkout gère le paiement
- webhook Stripe vérifié cryptographiquement avant mise à jour de l'abonnement
- portail Stripe prévu pour gérer l'abonnement sans exposer les données de paiement à ColorFit

## Stripe

Créer un produit récurrent dans Stripe et renseigner `STRIPE_PRICE_ID`, `STRIPE_SECRET_KEY` et `STRIPE_WEBHOOK_SECRET` dans `.env`.

Le webhook doit pointer vers `/api/stripe/webhook` et écouter au minimum :
- checkout.session.completed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted

### Production

- utiliser HTTPS uniquement
- `NODE_ENV=production`
- générer un `SESSION_SECRET` aléatoire d'au moins 32 octets
- utiliser PostgreSQL managé plutôt que SQLite si plusieurs instances sont déployées
- configurer les sauvegardes chiffrées et la rotation des secrets
- définir une politique de rétention/suppression des données
- configurer les domaines Stripe et les URLs de production
- ne jamais committer `.env`

## Important

L'analyse colorimétrique de cette version est un moteur local de démonstration et ne prétend pas faire une reconnaissance biométrique. Pour une analyse IA avancée, il faut brancher un modèle de vision spécialisé côté serveur avec traitement et rétention strictement minimisés.
